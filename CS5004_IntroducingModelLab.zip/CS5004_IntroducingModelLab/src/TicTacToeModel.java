import java.util.Arrays;
import java.util.stream.Collectors;

public class TicTacToeModel implements TicTacToe {
  // add your implementation here
  private  Player [][] board = new Player[3][3];
  Player player;
  private int turnCounter = 0;
  private boolean gameOver;

  //Constructor
  TicTacToeModel(){
    for(int i = 0; i<3; i++){
      for(int j = 0; j<3; j++){
        board[i][j] = null;
      }
    }
  }

  /**
   * Marks a move for the player and will throw an exception if the game has ended, if a space is occupied, or
   * a described space is out of bounds
   * @param r the row of the intended move
   * @param c the column of the intended move
   * @throws IllegalArgumentException
   * @throws IllegalStateException
   */
  @Override
  public void move(int r, int c) throws IllegalArgumentException, IllegalStateException {
      //Checks to see if the move is out of bounds of the array
      if (r < 0 || r > 3 || c < 0 || c > 3) {
      throw new IllegalArgumentException("Move is out of bounds!");
      }
      //Exception argument to check to see if the space is occupied
      if (board[r][c] != null) {
        throw new IllegalArgumentException("Space is occupied");
      }
      //Checks to see if the game is over
      if(gameOver == true){
        throw new IllegalStateException("Game is over!");
      }
      else{
        //gets turn of the current player
        getTurn();
        //Places players mark at selected position.
        board[r][c] = this.player;
        //Increases turn counter so next player is set.
        turnCounter+=1;
        if(getWinner() == this.player){
          gameOver = true;
        }
    }
  }

  /**
   * Logic that handles the players turn. Uses turn counter to keep track if player is X or O
   * @return returns the current player
   */
  @Override
  public Player getTurn() {
    if(turnCounter % 2 == 0){
      player = Player.X;
    }
    else{
      player = Player.O;
    }
    return this.player;

  }

  /**
   *Contains the logic if a game is over or the game will continue
   * @return returns a boolean value if the game is over or not
   */
  @Override
  public boolean isGameOver() {
    //Uses gameOver boolean and turnCounter int to determine if games is over or board is full
    if(gameOver == true || turnCounter >= 9){
      return true;
    }
    else{
      return false;
    }
  }

  /**
   * Provides logic for win conditions and returns the player who has three marks in a row
   * @return
   */
  @Override
  public Player getWinner() {
    //Left Column win
    if(board[0][0] == this.player && board[1][0] == this.player && board[2][0] == this.player){
      return this.player;
    }
    //Middle Column win
    if(board[0][1] == this.player && board[0][1] == this.player && board[0][2] == this.player){
      return this.player;
    }
    //Right column win
    if(board[0][1] == this.player && board[0][1] == this.player && board[0][2] == this.player){
      return this.player;
    }
    //Top row win
    if(board[0][0] == this.player && board[0][1] == this.player && board[0][2] == this.player){
      return this.player;
    }
    //Middle row win
    if(board[1][0] == this.player && board[1][1] == this.player && board[1][2] == this.player){
      return this.player;
    }
    //Bottom row win
    if(board[2][0] == this.player && board[2][1] == this.player && board[2][2] == this.player){
      return this.player;
    }
    //diagonal win from top left
    if(board[0][0] == this.player && board[1][1] == this.player && board[2][2] == this.player){
      return this.player;
    }
    //Diagonal win starting from top right
    if(board[0][2] == this.player && board[1][1] == this.player && board[2][0] == this.player){
      return this.player;
    }
    else{
      return null;
    }
  }

  /**
   * Returns the game board  in its current state
   * @return returns the game board
   */
  @Override
    public Player[][] getBoard() {
     return this.board;
  }

  /**
   * Returns the mark at the location described by the parameters
   * @param r the row
   * @param c the column
   * @return
   */
  @Override
  public Player getMarkAt(int r, int c) {
    if (r < 0 || r > 3 || c < 0 || c > 3) {
      throw new IllegalArgumentException("Selection is out of bounds!");
    }
    return this.board[r][c];
  }


  /**
   * Creates a toString method for ticTacToeModel
   * @return
   */
  @Override
  public String toString() {
    // Using Java stream API to save code:
    return Arrays.stream(getBoard()).map(
                    row -> " " + Arrays.stream(row).map(
                            p -> p == null ? " " : p.toString()).collect(Collectors.joining(" | ")))
            .collect(Collectors.joining("\n-----------\n"));
    // This is the equivalent code as above, but using iteration, and still using
    // the helpful built-in String.join method.
    /**********
     List<String> rows = new ArrayList<>();
     for(Player[] row : getBoard()) {
     List<String> rowStrings = new ArrayList<>();
     for(Player p : row) {
     if(p == null) {
     rowStrings.add(" ");
     } else {
     rowStrings.add(p.toString());
     }
     }
     rows.add(" " + String.join(" | ", rowStrings));
     }
     return String.join("\n-----------\n", rows);
     ************/
  }
}

