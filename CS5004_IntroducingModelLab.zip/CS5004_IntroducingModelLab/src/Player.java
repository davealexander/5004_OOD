public enum Player {
    O{
        public String toString(){
            return "O";
        }
    },
    X {
        public String toString() {
            return "X";
        };
    }

}
